﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VMS.Data;

namespace VMS.Models.Entry
{

    public class Visitor_Func
    {
        VMSEntities Entity = new VMSEntities();

        //List
        public List<Visitor_Prop> GetList()
        {
            try
            {
                IList<Visitor_Prop> data = (from a in Entity.Ent_Visitor
                                            select new Visitor_Prop
                                            {
                                                VID = a.VID,
                                                Vcode = a.Vcode,
                                                Vname = a.Vname,
                                                Vdate = a.Vdate,
                                                Vperson = a.Vperson,
                                                Vpurposeid = a.Vpurposeid,
                                                Vpurpose = Entity.Mas_Visitpurpose.Where(p => p.ID == a.Vpurposeid).FirstOrDefault().Vpurpose,
                                                Vmobile = a.Vmobile,
                                                Vaddr = a.Vaddr

                                            }).ToList();

                return data.ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }
        //Insert
        public string Insert(Visitor_Prop prop)
        {

            try
            {
                if (!Entity.Ent_Visitor.Where(a => a.Vcode == prop.Vcode).Any())
                {
                    Ent_Visitor dbdata = new Ent_Visitor();

                    dbdata.Vcode = prop.Vcode;
                    dbdata.Vname = prop.Vname;
                    dbdata.Vdate = prop.Vdate;
                    dbdata.Vperson = prop.Vperson;
                    dbdata.Vpurposeid = prop.Vpurposeid;
                    dbdata.Vmobile = prop.Vmobile;
                    dbdata.Vaddr = prop.Vaddr;
                    dbdata.Createdate = DateTime.Now;

                    Entity.Ent_Visitor.Add(dbdata);
                    Entity.SaveChanges();

                    return "Insert Successfully!";
                }
                else
                {
                    return "Already Exist!";
                }

            }
            catch (Exception)
            {
                throw;
            }

        }

        //Update
        public string Update(Visitor_Prop prop)
        {
            try
            {
                var dbdata = Entity.Ent_Visitor.Where(a => a.VID == prop.VID).FirstOrDefault();
                if (dbdata.Vcode == prop.Vcode)
                {
                    dbdata.Vcode = prop.Vcode;
                    dbdata.Vname = prop.Vname;
                    dbdata.Vdate = prop.Vdate;
                    dbdata.Vperson = prop.Vperson;
                    dbdata.Vpurposeid = prop.Vpurposeid;
                    dbdata.Vmobile = prop.Vmobile;
                    dbdata.Vaddr = prop.Vaddr;
                    dbdata.Updatedate = DateTime.Now;

                    Entity.SaveChanges();

                    return "Update Successfully!";
                }
                else
                {
                    if (!Entity.Ent_Visitor.Where(a => a.Vcode == prop.Vcode).Any())
                    {
                        dbdata.Vcode = prop.Vcode;
                        dbdata.Vname = prop.Vname;
                        dbdata.Vdate = prop.Vdate;
                        dbdata.Vperson = prop.Vperson;
                        dbdata.Vpurposeid = prop.Vpurposeid;
                        dbdata.Vmobile = prop.Vmobile;
                        dbdata.Vaddr = prop.Vaddr;
                        dbdata.Updatedate = DateTime.Now;

                        Entity.SaveChanges();

                        return "Update Successfully!";
                    }
                    else
                    {
                        return "Already Exist!";
                    }
                }

            }
            catch (Exception)
            {
                throw;
            }

        }

        //Retrieve
        public Visitor_Prop Retrieve(int VID)
        {
            try
            {
                Visitor_Prop prop = new Visitor_Prop();
                var dbdata = Entity.Ent_Visitor.Where(a => a.VID == VID).FirstOrDefault();

                prop.VID = dbdata.VID;
                prop.Vcode = dbdata.Vcode;
                prop.Vname = dbdata.Vname;
                prop.Vdate = dbdata.Vdate;
                prop.VdateS = dbdata.Vdate.ToString("yyyy-MM-ddTHH:mm");
                prop.Vperson = dbdata.Vperson;
                prop.Vpurposeid = dbdata.Vpurposeid;
                prop.Vmobile = dbdata.Vmobile;
                prop.Vaddr = dbdata.Vaddr;

                return prop;

            }
            catch (Exception)
            {
                throw;
            }

        }

        //Delete
        public string Delete(int VID)
        {
            try
            {
                var dbdata = Entity.Ent_Visitor.Where(a => a.VID == VID).FirstOrDefault();

                Entity.Ent_Visitor.Remove(dbdata);
                Entity.SaveChanges();

                return "Delete Successfully!";

            }
            catch (Exception)
            {
                throw;
            }

        }

        //Dropdown

        public List<Visitor_Prop> GetVpurpose()
        {
            try
            {
                IList<Visitor_Prop> data = (from a in Entity.Mas_Visitpurpose
                                            select new Visitor_Prop
                                            {
                                                Vpurposeid = a.ID,
                                                Vpurpose = a.Vpurpose
                                            }).ToList();

                return data.ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}