﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VMS.Models.Entry
{
    public class Visitor_Prop
    {
        public int VID { get; set; }
        public string Vcode { get; set; }
        public string Vname { get; set; }
        public System.DateTime Vdate { get; set; }
        public string Vperson { get; set; }
        public Nullable<int> Vpurposeid { get; set; }
        public string Vmobile { get; set; }
        public string Vaddr { get; set; }
        public DateTime Createdate { get; set; }
        public DateTime Updatedate { get; set; }
        public string VisitPurpose { get; internal set; }
        public string Vpurpose { get; internal set; }
        public string VdateS { get; internal set; }
    }
}