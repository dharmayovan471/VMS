﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VMS.Models.Entry;

namespace VMS.Controllers.Entry
{
    public class VisitorController : Controller
    {
        // GET: Visitor
        Visitor_Func func = new Visitor_Func();
        Visitor_Prop prop = new Visitor_Prop();
        public ActionResult Visitor()
        {
            return View();
        }
     
        //Load Grid
        public JsonResult LoadGrid()
        {
            try
            {
                var result = func.GetList();
                foreach (var item in result)
                {
                    item.VdateS = item.Vdate.ToString("yyyy-MM-dd HH:mm");
                }

                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {

                throw;
            }
        }
        //Insert Update
        public JsonResult InsertUpdate()
        {
            try
            {
                var result = "";
                prop.Vcode = Request["Vcode"].ToString();
                prop.Vname = Request["Vname"].ToString();
                prop.Vdate = Convert.ToDateTime(Request["Vdate"].ToString());
                prop.Vperson = Request["Vperson"].ToString();
                prop.Vpurposeid = Convert.ToInt32(Request["Vpurposeid"].ToString());
                prop.Vmobile = Request["Vmobile"].ToString();
                prop.Vaddr = Request["Vaddr"].ToString();

                if (string.IsNullOrEmpty(Request["VID"].ToString()))
                {
                    result = func.Insert(prop);
                }
                else
                {
                    prop.VID = Convert.ToInt32(Request["VID"].ToString());
                    result = func.Update(prop);
                }


                return Json(result);
            }
            catch (Exception)
            {

                throw;
            }
        }

        //Retrieve
        public JsonResult Retrieve(int VID)
        {
            try
            {
                var result = func.Retrieve(VID);

                return Json(result);
            }
            catch (Exception)
            {

                throw;
            }
        }
        //Delete
        public ActionResult Delete(int VID)
        {
            try
            {
                var result = func.Delete(VID);

                return Json(result);
            }
            catch (Exception)
            {

                throw;
            }
        }

        //DropDown
        public JsonResult GetVpurpose()
        {
            try
            {
                var result = func.GetVpurpose();

                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}